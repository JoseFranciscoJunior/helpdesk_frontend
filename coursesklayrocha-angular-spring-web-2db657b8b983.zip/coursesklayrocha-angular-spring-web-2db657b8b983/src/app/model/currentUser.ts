import { User } from './user';

export class CurrentUser {
    public token: string;
    public user: User;
  }
  
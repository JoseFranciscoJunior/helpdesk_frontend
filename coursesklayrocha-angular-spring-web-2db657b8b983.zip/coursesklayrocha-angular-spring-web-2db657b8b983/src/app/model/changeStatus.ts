import { User } from './user';

export class ChangeStatus {
    public userChange: User;
    public dateChangeStatus: string;
    public status: string;
}